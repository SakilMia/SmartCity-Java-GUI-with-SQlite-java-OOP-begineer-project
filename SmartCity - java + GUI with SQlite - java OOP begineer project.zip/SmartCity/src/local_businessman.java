/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class local_businessman extends businessman{
    
    local_businessman(String name,String phoneNo,String companyName,String address,String gender,String id)
    {
        super(name,phoneNo,companyName,address,gender,id);
    }
}
